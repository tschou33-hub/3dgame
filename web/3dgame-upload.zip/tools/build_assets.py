"""Create original paper-cut Dream Market assets for Godot."""
import bpy
import math
import os
from mathutils import Vector

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSET_DIR = os.path.join(ROOT, "assets")
os.makedirs(ASSET_DIR, exist_ok=True)

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.collections,):
    for block in list(datablocks):
        if block.name != "Collection":
            datablocks.remove(block)

def material(name, color, roughness=0.9):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    bsdf.inputs["Base Color"].default_value = (*color, 1)
    bsdf.inputs["Roughness"].default_value = roughness
    return m

PALETTE = {
    "sky": material("紙色｜晨霧青", (0.55, 0.76, 0.78)),
    "cream": material("紙色｜奶油白", (0.96, 0.91, 0.78)),
    "ochre": material("紙色｜烤糖橘", (0.78, 0.40, 0.25)),
    "teal": material("紙色｜湖水綠", (0.27, 0.46, 0.45)),
    "sage": material("紙色｜鼠尾草", (0.48, 0.61, 0.47)),
    "rose": material("紙色｜莓果粉", (0.78, 0.49, 0.48)),
    "plum": material("紙色｜暮紫", (0.36, 0.31, 0.42)),
    "wood": material("紙色｜胡桃木", (0.42, 0.31, 0.24)),
    "gold": material("紙色｜夢幣金", (0.93, 0.68, 0.28), 0.5),
    "ink": material("紙色｜夜墨", (0.16, 0.22, 0.25)),
    "skin": material("紙色｜暖桃膚", (0.87, 0.59, 0.44)),
    "blue": material("紙色｜旅人藍", (0.30, 0.43, 0.48)),
    "leaf": material("紙色｜新芽", (0.37, 0.58, 0.39)),
    "lilac": material("紙色｜星花紫", (0.66, 0.52, 0.72)),
}

def collection(name, parent=None):
    c = bpy.data.collections.new(name)
    (parent or bpy.context.scene.collection).children.link(c)
    return c

def relink(obj, coll):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    coll.objects.link(obj)

def parent_to(obj, parent):
    obj.parent = parent

def empty(name, coll, location=(0,0,0)):
    obj = bpy.data.objects.new(name, None)
    obj.empty_display_type = "PLAIN_AXES"
    obj.location = location
    coll.objects.link(obj)
    return obj

def box(name, coll, parent, loc, scale, mat, bevel=0.06):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    relink(obj, coll)
    if mat: obj.data.materials.append(mat)
    if bevel:
        mod = obj.modifiers.new("Soft cut-paper edge", "BEVEL")
        mod.width = bevel
        mod.segments = 1
        obj.modifiers.new("Cardboard normals", "WEIGHTED_NORMAL")
    parent_to(obj, parent)
    return obj

def sphere(name, coll, parent, loc, scale, mat, segments=12, rings=8):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=segments, ring_count=rings, radius=1, location=loc)
    obj = bpy.context.object
    obj.name = name
    obj.scale = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    relink(obj, coll)
    if mat: obj.data.materials.append(mat)
    for p in obj.data.polygons: p.use_smooth = False
    parent_to(obj, parent)
    return obj

def cone(name, coll, parent, loc, radius, depth, mat, vertices=7):
    bpy.ops.mesh.primitive_cone_add(vertices=vertices, radius1=radius, radius2=0, depth=depth, location=loc)
    obj = bpy.context.object
    obj.name = name
    relink(obj, coll)
    obj.data.materials.append(mat)
    parent_to(obj, parent)
    return obj

def cylinder(name, coll, parent, loc, radius, depth, mat, vertices=16):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc)
    obj = bpy.context.object
    obj.name = name
    relink(obj, coll)
    obj.data.materials.append(mat)
    parent_to(obj, parent)
    return obj

scene_coll = bpy.context.scene.collection
level1_coll = collection("Level1")
level2_coll = collection("Level2")
player_coll = collection("Player")
level1 = empty("Level1", level1_coll)
level2 = empty("Level2", level2_coll)
# Blender Y maps to Godot -Z. Keep the traveler in front of the paper platform
# so the foreground board cannot occlude the character in Godot's Y-up scene.
player = empty("Player", player_coll, (-4.2, -1.3, 0.3))
# The character is authored with Y as its height axis; Blender is Z-up.
# Rotate the root so glTF/Godot receives an upright Y-up character.
player.rotation_euler.x = math.radians(90)

# Original child adventurer, built as a layered Blender character model.
# The tapered coat is custom mesh geometry; the smaller paper-like pieces add
# a readable face, clothes, travel gear, and a warm lantern at game scale.
coat_verts = [
    (-0.38, 0.40, 0.24), (0.38, 0.40, 0.24), (0.29, 1.22, 0.24), (-0.29, 1.22, 0.24),
    (-0.38, 0.40, -0.22), (0.38, 0.40, -0.22), (0.29, 1.22, -0.22), (-0.29, 1.22, -0.22),
]
coat_faces = [(0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1), (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)]
coat_mesh = bpy.data.meshes.new("旅人｜剪裁紙衣網格")
coat_mesh.from_pydata(coat_verts, [], coat_faces)
coat_mesh.materials.append(PALETTE["blue"])
coat_mesh.update()
coat = bpy.data.objects.new("旅人｜剪裁紙衣", coat_mesh)
player_coll.objects.link(coat)
parent_to(coat, player)
coat_bevel = coat.modifiers.new("紙衣柔邊", "BEVEL")
coat_bevel.width = 0.055
coat_bevel.segments = 1
coat.modifiers.new("紙衣法線", "WEIGHTED_NORMAL")

# Two visible legs and chunky boots give the coat a clear walking silhouette.
for side in (-1, 1):
    box("旅人｜褲管", player_coll, player, (side * 0.17, 0.34, 0.02), (0.22, 0.38, 0.30), PALETTE["teal"], 0.07)
    box("旅人｜靴筒", player_coll, player, (side * 0.19, 0.13, 0.08), (0.28, 0.22, 0.38), PALETTE["plum"], 0.07)
    box("旅人｜靴尖", player_coll, player, (side * 0.19, 0.10, 0.24), (0.30, 0.14, 0.18), PALETTE["ochre"], 0.06)

# Sleeves, cuffs and hands are posed slightly out from the body.
for side in (-1, 1):
    sleeve = box("旅人｜外套袖", player_coll, player, (side * 0.43, 0.91, 0.02), (0.24, 0.62, 0.30), PALETTE["blue"], 0.10)
    sleeve.rotation_euler.z = side * math.radians(14)
    cuff = box("旅人｜奶油袖口", player_coll, player, (side * 0.52, 0.62, 0.04), (0.24, 0.13, 0.31), PALETTE["cream"], 0.045)
    cuff.rotation_euler.z = side * math.radians(14)
    sphere("旅人｜小手", player_coll, player, (side * 0.54, 0.51, 0.08), (0.13, 0.13, 0.13), PALETTE["skin"], 10, 6)

# Neckline and a layered scarf with a short front tail.
box("旅人｜襯衣領", player_coll, player, (0, 1.20, 0.18), (0.38, 0.22, 0.18), PALETTE["cream"], 0.05)
box("旅人｜圍巾", player_coll, player, (0, 1.24, 0.25), (0.62, 0.16, 0.18), PALETTE["rose"], 0.055)
scarf_tail = box("旅人｜圍巾尾", player_coll, player, (0.17, 1.04, 0.29), (0.18, 0.35, 0.09), PALETTE["rose"], 0.04)
scarf_tail.rotation_euler.z = math.radians(-12)

# Rounded face, visible ears, hair, expressive eyes, cheeks, nose and smile.
sphere("旅人｜臉", player_coll, player, (0, 1.60, 0.04), (0.36, 0.39, 0.32), PALETTE["skin"])
sphere("旅人｜瀏海", player_coll, player, (0, 1.84, -0.01), (0.38, 0.20, 0.31), PALETTE["wood"], 12, 8)
for side in (-1, 1):
    sphere("旅人｜耳朵", player_coll, player, (side * 0.34, 1.57, 0.03), (0.09, 0.12, 0.10), PALETTE["skin"], 10, 6)
    sphere("旅人｜眼白", player_coll, player, (side * 0.13, 1.62, 0.335), (0.072, 0.085, 0.035), PALETTE["cream"], 10, 6)
    sphere("旅人｜眼睛", player_coll, player, (side * 0.13, 1.62, 0.366), (0.040, 0.055, 0.025), PALETTE["ink"], 10, 6)
    sphere("旅人｜眼神亮點", player_coll, player, (side * 0.12, 1.645, 0.388), (0.015, 0.018, 0.012), PALETTE["cream"], 8, 5)
    sphere("旅人｜臉頰", player_coll, player, (side * 0.22, 1.48, 0.29), (0.065, 0.035, 0.025), PALETTE["rose"], 10, 6)
sphere("旅人｜鼻尖", player_coll, player, (0, 1.51, 0.355), (0.045, 0.05, 0.035), PALETTE["ochre"], 10, 6)
mouth = bpy.data.curves.new("旅人｜微笑曲線", "CURVE")
mouth.dimensions = "3D"
mouth.bevel_depth = 0.012
mouth.bevel_resolution = 2
mouth_spline = mouth.splines.new("POLY")
mouth_spline.points.add(2)
for point, co in zip(mouth_spline.points, [(-0.075, 1.405, 0.33, 1), (0, 1.38, 0.35, 1), (0.075, 1.405, 0.33, 1)]):
    point.co = co
mouth_obj = bpy.data.objects.new("旅人｜微笑", mouth)
player_coll.objects.link(mouth_obj)
mouth_obj.data.materials.append(PALETTE["wood"])
parent_to(mouth_obj, player)

# Explorer cap: a soft crown, broad brim and a berry-coloured band.
box("旅人｜帽簷", player_coll, player, (0, 1.88, 0.03), (0.88, 0.12, 0.52), PALETTE["ochre"], 0.055)
sphere("旅人｜帽冠", player_coll, player, (0, 1.98, -0.01), (0.31, 0.20, 0.30), PALETTE["teal"], 12, 8)
box("旅人｜帽帶", player_coll, player, (0, 1.93, 0.275), (0.38, 0.07, 0.035), PALETTE["rose"], 0.02)
sphere("旅人｜帽上星章", player_coll, player, (0, 1.99, 0.292), (0.07, 0.07, 0.03), PALETTE["gold"], 8, 5)

# Satchel, diagonal strap and stitched front flap.
backpack = box("旅人｜小背包", player_coll, player, (-0.39, 0.80, -0.17), (0.30, 0.52, 0.30), PALETTE["ochre"], 0.08)
box("旅人｜背包側袋", player_coll, player, (-0.55, 0.75, -0.01), (0.14, 0.25, 0.18), PALETTE["rose"], 0.04)
strap = box("旅人｜斜背帶", player_coll, player, (-0.04, 0.83, 0.285), (0.085, 0.84, 0.055), PALETTE["ochre"], 0.025)
strap.rotation_euler.z = math.radians(34)
box("旅人｜小包", player_coll, player, (-0.34, 0.65, 0.34), (0.34, 0.37, 0.18), PALETTE["ochre"], 0.06)
box("旅人｜小包翻蓋", player_coll, player, (-0.34, 0.72, 0.445), (0.31, 0.17, 0.035), PALETTE["rose"], 0.025)
sphere("旅人｜小包扣", player_coll, player, (-0.34, 0.68, 0.47), (0.045, 0.045, 0.025), PALETTE["gold"], 8, 5)

# Coat details: cream lapels and two dream-coin buttons.
for side in (-1, 1):
    lapel = box("旅人｜紙衣翻領", player_coll, player, (side * 0.11, 1.08, 0.275), (0.17, 0.31, 0.045), PALETTE["cream"], 0.025)
    lapel.rotation_euler.z = side * math.radians(20)
for y in (0.88, 0.70):
    sphere("旅人｜夢幣鈕扣", player_coll, player, (0.05, y, 0.265), (0.045, 0.045, 0.025), PALETTE["gold"], 8, 5)

# A warm paper lantern is carried out to the right side of the silhouette.
box("旅人｜提燈把手", player_coll, player, (0.57, 0.74, 0.20), (0.09, 0.27, 0.10), PALETTE["wood"], 0.025)
box("旅人｜小提燈", player_coll, player, (0.57, 0.55, 0.26), (0.24, 0.30, 0.24), PALETTE["gold"], 0.045)
box("旅人｜提燈窗格", player_coll, player, (0.57, 0.55, 0.395), (0.11, 0.19, 0.025), PALETTE["cream"], 0.025)
cone("旅人｜提燈頂", player_coll, player, (0.57, 0.73, 0.26), 0.17, 0.12, PALETTE["ochre"], 6)
sphere("旅人｜提燈底", player_coll, player, (0.57, 0.38, 0.26), (0.12, 0.06, 0.12), PALETTE["ochre"], 8, 5)

def make_backdrop(coll, root, level_two=False):
    box("天空｜大色紙", coll, root, (0,3.5,-2.4), (19,9,0.2), PALETTE["sky"], 0)
    box("地面｜厚紙平台", coll, root, (0,-0.48,0), (19,0.48,4), PALETTE["cream"], 0.12)
    # distant soft hills as layered, broad low-poly mounds
    for i, (x, width, height, mat) in enumerate([(-6,5,1.8,PALETTE["sage"]),(0,5,1.4,PALETTE["cream"]),(6,6,2.1,PALETTE["sage"])]):
        sphere("遠景｜紙丘%d" % i, coll, root, (x,0.2,-1.5), (width/2,height/2,0.36), mat, 10, 5)
    # layered floor stripe
    box("前景｜草綠紙帶", coll, root, (0,-0.20,-0.8), (19,0.18,0.12), PALETTE["sage"], 0.03)

def market_stall(coll, root, x, palette_index=0):
    colors = [PALETTE["ochre"], PALETTE["rose"], PALETTE["teal"]]
    accent = colors[palette_index % len(colors)]
    g = empty("夜市攤位｜紙雕", coll, (x,0,0))
    parent_to(g, root)
    box("攤位｜木桌", coll, g, (0,0.8,0.3), (3.1,0.48,1.1), PALETTE["wood"],0.06)
    for dx in (-1.25,1.25):
        box("攤位｜桌腳", coll, g, (dx,0.23,0.34),(0.22,0.78,0.28),PALETTE["wood"],0.04)
        box("攤位｜立柱", coll, g, (dx,2.12,-0.1),(0.18,2.0,0.2),PALETTE["teal"],0.04)
    box("攤位｜遮棚", coll, g, (0,2.95,-0.08),(3.35,0.28,1.5),PALETTE["cream"],0.03)
    for j in range(5):
        x2=-1.22+j*0.61
        box("攤位｜彩紙垂片", coll, g, (x2,2.70,-0.04),(0.30,0.28,1.48),accent if j%2 else PALETTE["cream"],0.02)
    for j in range(3):
        cylinder("攤位｜夢幣展示", coll, g, (-0.72+j*0.65,1.24,0.9),0.22,0.08,PALETTE["gold"],16)
    for j, col in enumerate([PALETTE["lilac"],PALETTE["rose"],PALETTE["sage"]]):
        box("攤位｜小禮盒", coll,g,(0.9,1.25+j*0.01,0.8),(0.34,0.40,0.32),col,0.04)

def lamp(coll, root, x):
    box("紙燈｜立柱",coll,root,(x,1.35,-0.3),(0.14,2.7,0.16),PALETTE["wood"],0.04)
    sphere("紙燈｜暖光",coll,root,(x,2.75,-0.28),(0.36,0.48,0.32),PALETTE["gold"],8,6)
    cone("紙燈｜小屋頂",coll,root,(x,3.22,-0.28),0.52,0.45,PALETTE["ochre"],6)

make_backdrop(level1_coll, level1)
market_stall(level1_coll, level1, -5.1, 0)
market_stall(level1_coll, level1, 5.2, 1)
lamp(level1_coll, level1, 0.3)
for x in (-7.3, 7.3):
    sphere("夜市｜紙燈籠", level1_coll, level1, (x,3.9,-1.0), (0.32,0.46,0.3), PALETTE["rose"], 8, 5)

# Level two is a calm seed garden and savings vault, not a trading floor.
make_backdrop(level2_coll, level2, True)
box("花園｜遠方拱門",level2_coll,level2,(0,2.45,-1.1),(5.3,4.5,0.4),PALETTE["teal"],0.24)
box("花園｜拱門內紙色",level2_coll,level2,(0,2.15,-0.82),(3.5,3.8,0.28),PALETTE["sky"],0.18)
for i, x in enumerate((-5.0,0.0,5.0)):
    col = [PALETTE["teal"],PALETTE["sage"],PALETTE["ochre"]][i]
    box("花園｜星種盆",level2_coll,level2,(x,0.30,0.2),(2.7,0.65,1.0),col,0.16)
    for j in range(3):
        sx=x-0.65+j*0.65
        box("花園｜新芽莖",level2_coll,level2,(sx,1.15,0.18),(0.10,1.2,0.10),PALETTE["leaf"],0.03)
        sphere("花園｜星形花",level2_coll,level2,(sx,1.85,0.18),(0.38,0.38,0.26),PALETTE["lilac"] if (j+i)%2 else PALETTE["gold"],8,5)
        sphere("花園｜葉片",level2_coll,level2,(sx+0.25,1.15,0.18),(0.27,0.14,0.15),PALETTE["leaf"],8,4)
for x in (-7.3,7.3):
    box("花園｜紙樹樹幹",level2_coll,level2,(x,1.0,-0.2),(0.42,2.0,0.32),PALETTE["wood"],0.06)
    for y, r in ((2.3,1.2),(3.1,0.9)):
        sphere("花園｜紙樹樹冠",level2_coll,level2,(x,y,-0.2),(r,r,0.52),PALETTE["sage"],9,5)

# Lighting and camera make the .blend pleasant to inspect.
world = bpy.data.worlds.new("柔和奶油色世界") if not bpy.data.worlds else bpy.data.worlds[0]
bpy.context.scene.world = world
world.use_nodes = True
world.node_tree.nodes["Background"].inputs["Color"].default_value = (0.62,0.74,0.73,1)
world.node_tree.nodes["Background"].inputs["Strength"].default_value = 0.8
ld = bpy.data.lights.new("紙雕柔光", "AREA")
lo = bpy.data.objects.new("紙雕柔光", ld)
bpy.context.scene.collection.objects.link(lo)
lo.location=(0,7,8)
ld.energy=1100
ld.shape="DISK"
ld.size=10

bpy.ops.object.select_all(action="DESELECT")
for root in (level1, level2, player):
    root.select_set(True)
for obj in bpy.context.scene.objects:
    if obj.type == "MESH": obj.select_set(True)
bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]

blend_path = os.path.join(ASSET_DIR,"dream_market_set.blend")
bpy.ops.wm.save_as_mainfile(filepath=blend_path)
glb_path = os.path.join(ASSET_DIR,"dream_market_set.glb")
bpy.ops.export_scene.gltf(filepath=glb_path, export_format="GLB", use_selection=True, export_apply=True, export_cameras=False, export_lights=False)
print("Created", blend_path, glb_path)
