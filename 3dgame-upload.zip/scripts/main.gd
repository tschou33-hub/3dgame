extends Node3D

const ART_SCENE: PackedScene = preload("res://assets/dream_market_set.glb")
const INK := Color("41434a")
const PAPER := Color("fff8e7")
const TEAL := Color("55777a")
const CORAL := Color("c47755")
const GOLD := Color("e6af4f")

var level := 0
var scores: Array[int] = [0, 0]
var attempts: Array[int] = [0, 0]
var coins := [4, 4, 2]
var seeds := [6, 0, 0]
var selected_reason := -1
var assessment_stage := ""
var assessment_index := 0
var pretest_score := 0
var posttest_score := 0
var art: Node3D
var player: Node3D
var score_label: Label
var key_label: Label
var prompt_label: Label
var feedback_label: Label
var interaction_box: VBoxContainer
var action_button: Button
var reason_button: Button
var movement_hint: Label
var modal: PanelContainer

func _ready() -> void:
	_build_world()
	_build_ui()
	_show_level()
	_start_assessment(true)

func _build_world() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("b8d8e0")
	sky_mat.sky_horizon_color = Color("f4d5a6")
	sky_mat.ground_bottom_color = Color("6b8d83")
	sky_mat.ground_horizon_color = Color("d3bd98")
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("fff0d4")
	env.ambient_light_energy = 0.7
	world.environment = env
	add_child(world)

	var camera := Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 14.8
	camera.position = Vector3(0, 4.5, 18)
	add_child(camera)
	camera.look_at(Vector3(0, 2.3, 0), Vector3.UP)

	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-28, -20, 0)
	light.light_color = Color("fff1d1")
	light.light_energy = 1.25
	add_child(light)

	art = ART_SCENE.instantiate() as Node3D
	add_child(art)
	player = art.get_node_or_null("Player")
	if player == null:
		player = _make_fallback_player()
		add_child(player)
	
	var floor := MeshInstance3D.new()
	var floor_mesh := BoxMesh.new()
	floor_mesh.size = Vector3(24, 0.35, 3)
	floor.mesh = floor_mesh
	floor.position = Vector3(0, -0.68, 0)
	floor.material_override = _mat(Color("d9c9a8"))
	add_child(floor)

func _build_ui() -> void:
	var canvas := CanvasLayer.new()
	add_child(canvas)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var ui_theme := Theme.new()
	ui_theme.default_font = load("res://assets/NotoSansTC.ttf") as Font
	root.theme = ui_theme
	canvas.add_child(root)

	var top := HBoxContainer.new()
	top.position = Vector2(28, 20)
	top.size = Vector2(1224, 88)
	root.add_child(top)
	var title_stack := VBoxContainer.new()
	title_stack.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(title_stack)
	var brand := _label("夢市預算站", 17, Color("a76448"), true)
	title_stack.add_child(brand)
	var title := _label("小小夢行者的理財冒險", 28, INK, true)
	title_stack.add_child(title)
	var stats := VBoxContainer.new()
	stats.custom_minimum_size.x = 300
	top.add_child(stats)
	key_label = _label("鑰匙 0 / 2", 18, INK, true)
	key_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	stats.add_child(key_label)
	score_label = _label("本關得分  0 / 100", 21, Color("a76448"), true)
	score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	stats.add_child(score_label)

	movement_hint = _label("A / D 或 ← / →　沿夢市探索", 15, Color("fff8e7"), false)
	movement_hint.position = Vector2(32, 661)
	movement_hint.size = Vector2(440, 32)
	root.add_child(movement_hint)

	var card := PanelContainer.new()
	card.position = Vector2(480, 128)
	card.size = Vector2(770, 455)
	card.add_theme_stylebox_override("panel", _panel_style(PAPER, Color("b99a78"), 22))
	root.add_child(card)
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 22)
	margin.add_theme_constant_override("margin_bottom", 18)
	card.add_child(margin)
	interaction_box = VBoxContainer.new()
	interaction_box.add_theme_constant_override("separation", 12)
	margin.add_child(interaction_box)

	var objective := _label("把 10 枚夢幣分給三個目標", 23, INK, true)
	interaction_box.add_child(objective)
	prompt_label = _label("先照顧需要，再安排想要與未來。", 16, Color("65666a"))
	interaction_box.add_child(prompt_label)

	var hint := _label("按 + 從其他目標挪一枚；按 − 留作未分配。", 15, Color("65666a"))
	hint.name = "Hint"
	interaction_box.add_child(hint)

	feedback_label = _label("調整分配後，選擇一個理由再檢查。", 15, Color("55777a"), true)
	feedback_label.custom_minimum_size.y = 28
	interaction_box.add_child(feedback_label)

	var footer := HBoxContainer.new()
	footer.add_theme_constant_override("separation", 12)
	interaction_box.add_child(footer)
	reason_button = Button.new()
	reason_button.text = "選擇理由　⌄"
	reason_button.custom_minimum_size = Vector2(250, 46)
	reason_button.pressed.connect(_open_reason_picker)
	_style_button(reason_button, PAPER, TEAL, INK)
	footer.add_child(reason_button)
	action_button = Button.new()
	action_button.text = "檢查分配"
	action_button.custom_minimum_size = Vector2(190, 46)
	action_button.pressed.connect(_submit_answer)
	_style_button(action_button, CORAL, Color("8a593e"), PAPER)
	footer.add_child(action_button)
	var score_spacer := Control.new()
	score_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	footer.add_child(score_spacer)
	var total := _label("總夢幣：10", 16, INK, true)
	total.name = "Total"
	footer.add_child(total)

	modal = PanelContainer.new()
	modal.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	modal.position = Vector2(-230, -115)
	modal.size = Vector2(460, 230)
	modal.visible = false
	modal.add_theme_stylebox_override("panel", _panel_style(PAPER, Color("b99a78"), 22))
	root.add_child(modal)

func _show_level() -> void:
	var l1 := art.get_node_or_null("Level1")
	var l2 := art.get_node_or_null("Level2")
	if l1: l1.visible = level == 0
	if l2: l2.visible = level == 1
	key_label.text = "鑰匙 %d / 2" % _keys()
	score_label.text = "本關得分  %d / 100" % scores[level]
	feedback_label.text = "調整分配後，選擇一個理由再檢查。"
	reason_button.text = "選擇理由　⌄"
	for child in interaction_box.get_children():
		if child.name == "Dynamic":
			interaction_box.remove_child(child)
			child.queue_free()
	if level == 0:
		prompt_label.text = "第一關｜夜市零用錢\n分配 10 枚夢幣：需要至少 4、想要不超過 3、未來至少 2。"
		_build_allocation_controls("coins", ["需要", "想要", "未來"], coins)
		var hint: Label = interaction_box.get_node_or_null("Hint")
		if hint: hint.text = "按 + 從其他目標挪一枚；按 − 留作未分配。"
	else:
		prompt_label.text = "第二關｜星種花園\n分配 6 顆星種：安全盆至少 2 顆，另外兩盆各放至少 1 顆。"
		_build_allocation_controls("seeds", ["安全盆", "穩穩盆", "成長盆"], seeds)
		var hint: Label = interaction_box.get_node_or_null("Hint")
		if hint: hint.text = "按 + 從其他花盆挪一顆；分散星種可降低風險。"
	var total: Label = interaction_box.get_node_or_null("Total")
	if total:
		var values: Array = coins if level == 0 else seeds
		var amount := 10 if level == 0 else 6
		total.text = "已分配：%d / %d" % [_sum(values), amount]

func _build_allocation_controls(kind: String, names: Array[String], values: Array) -> void:
	var row := HBoxContainer.new()
	row.name = "Dynamic"
	row.add_theme_constant_override("separation", 10)
	interaction_box.add_child(row)
	interaction_box.move_child(row, 2)
	for i in range(3):
		var column := VBoxContainer.new()
		column.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(column)
		var name_label := _label(names[i], 15, INK, true)
		name_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		column.add_child(name_label)
		var controls := HBoxContainer.new()
		controls.alignment = BoxContainer.ALIGNMENT_CENTER
		column.add_child(controls)
		var minus := Button.new()
		minus.text = "−"
		minus.custom_minimum_size = Vector2(42, 44)
		minus.pressed.connect(_change_value.bind(kind, i, -1))
		_style_button(minus, Color("e9e2d2"), Color("b99a78"), INK)
		controls.add_child(minus)
		var value_label := _label("%d" % values[i], 23, INK, true)
		value_label.name = "%sValue%d" % [kind, i]
		value_label.custom_minimum_size = Vector2(48, 44)
		value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		controls.add_child(value_label)
		var plus := Button.new()
		plus.text = "+"
		plus.custom_minimum_size = Vector2(42, 44)
		plus.pressed.connect(_change_value.bind(kind, i, 1))
		_style_button(plus, Color("e9e2d2"), Color("b99a78"), INK)
		controls.add_child(plus)

func _change_value(kind: String, index: int, delta: int) -> void:
	var values: Array = coins if kind == "coins" else seeds
	var total := 10 if kind == "coins" else 6
	var message := ""
	if delta < 0:
		if values[index] <= 0:
			return
		values[index] -= 1
		message = "已留出 1 單位未分配；按 + 可再放入目標。"
	else:
		if _sum(values) < total:
			values[index] += 1
			message = "已增加 1 單位。"
		else:
			var donor_index := -1
			for i in range(3):
				if i != index and (donor_index < 0 or values[i] > values[donor_index]):
					donor_index = i
			if donor_index < 0 or values[donor_index] <= 0:
				return
			var names := ["需要", "想要", "未來"] if kind == "coins" else ["安全盆", "穩穩盆", "成長盆"]
			values[donor_index] -= 1
			values[index] += 1
			message = "已從「%s」挪 1 單位到「%s」。" % [names[donor_index], names[index]]
	selected_reason = -1
	reason_button.text = "選擇理由　⌄"
	feedback_label.text = message
	for i in range(3):
		var value_label := interaction_box.find_child("%sValue%d" % [kind, i], true, false) as Label
		if value_label:
			value_label.text = str(values[i])
	var total_label: Label = interaction_box.get_node_or_null("Total")
	if total_label:
		total_label.text = "已分配：%d / %d" % [_sum(values), total]

func _open_reason_picker() -> void:
	for child in modal.get_children(): child.queue_free()
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 20)
	margin.add_theme_constant_override("margin_right", 20)
	margin.add_theme_constant_override("margin_top", 16)
	margin.add_theme_constant_override("margin_bottom", 14)
	modal.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	margin.add_child(box)
	var title := _label("選一個符合你想法的理由", 18, INK, true)
	box.add_child(title)
	var reasons := ["先顧需要，也替未來留一些。", "把所有錢用在現在最想要的東西。", "分散星種，避免只靠一種結果。"]
	if level == 1:
		reasons = ["只選看起來長最快的花盆。", "先照顧備用，再分散星種。", "把所有星種放在同一盆。"]
	for i in range(reasons.size()):
		var b := Button.new()
		b.text = reasons[i]
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.pressed.connect(_select_reason.bind(i))
		_style_button(b, Color("fffdf5"), Color("c9b99f"), INK)
		box.add_child(b)
	var close := Button.new()
	close.text = "返回"
	close.pressed.connect(func(): modal.visible = false)
	box.add_child(close)
	modal.visible = true

func _select_reason(index: int) -> void:
	selected_reason = index
	reason_button.text = "理由已選　✓"
	feedback_label.text = "理由已選好，按「檢查分配」看看結果。"
	modal.visible = false

func _submit_answer() -> void:
	if selected_reason < 0:
		feedback_label.text = "先選一個理由，再檢查分配。"
		return
	attempts[level] += 1
	var correct := false
	if level == 0:
		correct = _sum(coins) == 10 and coins[0] >= 4 and coins[1] <= 3 and coins[2] >= 2 and selected_reason == 0
	else:
		var nonzero := 0
		for amount in seeds:
			if amount > 0: nonzero += 1
		correct = _sum(seeds) == 6 and seeds[0] >= 2 and seeds[1] >= 1 and seeds[2] >= 1 and nonzero == 3 and selected_reason == 1
	if correct:
		var earned := maxi(60, 100 - (attempts[level] - 1) * 10)
		scores[level] = earned
		feedback_label.text = "答對了！%s" % ("需要、想要和未來都有安排。" if level == 0 else "有備用，也分散了結果風險。")
		key_label.text = "鑰匙 %d / 2" % _keys()
		action_button.text = "取得鑰匙"
		action_button.pressed.disconnect(_submit_answer)
		action_button.pressed.connect(_advance_level)
		score_label.text = "本關得分  %d / 100" % scores[level]
	else:
		feedback_label.text = "再想一想：%s" % ("需要優先，想要和未來也要有安排。" if level == 0 else "保留至少兩顆備用，另外兩盆也各放一些星種。")

func _advance_level() -> void:
	if level == 0:
		level = 1
		selected_reason = -1
		action_button.text = "檢查分配"
		action_button.pressed.disconnect(_advance_level)
		action_button.pressed.connect(_submit_answer)
		_show_level()
	else:
		_start_assessment(false)

func _start_assessment(is_pretest: bool) -> void:
	assessment_stage = "pre" if is_pretest else "post"
	assessment_index = 0
	if is_pretest:
		pretest_score = 0
	else:
		posttest_score = 0
	_render_assessment_question()

func _render_assessment_question() -> void:
	for child in modal.get_children(): child.queue_free()
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 18)
	modal.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	margin.add_child(box)
	var phase := "開始前" if assessment_stage == "pre" else "遊戲後"
	box.add_child(_label("%s小小理財檢視（%d / 2）" % [phase, assessment_index + 1], 18, Color("a76448"), true))
	var question := "有 10 枚夢幣，想買東西也想存目標，先做什麼？" if assessment_index == 0 else "有 6 顆星種，怎麼降低只靠一種結果的風險？"
	box.add_child(_label(question, 17, INK, true))
	var options := [
		["先安排需要、想要和未來目標", "全部拿去買最喜歡的東西"],
		["全部放在看起來長最快的一盆", "分散到至少兩盆並留一些備用"]
	]
	for i in range(2):
		var button := Button.new()
		button.text = options[assessment_index][i]
		button.custom_minimum_size.y = 48
		button.pressed.connect(_answer_assessment.bind(i == (0 if assessment_index == 0 else 1)))
		_style_button(button, Color("fffdf5"), Color("c9b99f"), INK)
		box.add_child(button)
	modal.visible = true

func _answer_assessment(is_correct: bool) -> void:
	if is_correct:
		if assessment_stage == "pre": pretest_score += 1
		else: posttest_score += 1
	assessment_index += 1
	if assessment_index < 2:
		_render_assessment_question()
	elif assessment_stage == "pre":
		modal.visible = false
		feedback_label.text = "開始前檢視已記錄，完成兩關後會用相同題目回顧。"
	else:
		_show_results()

func _show_results() -> void:
	for child in modal.get_children(): child.queue_free()
	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 26)
	margin.add_theme_constant_override("margin_right", 26)
	margin.add_theme_constant_override("margin_top", 24)
	margin.add_theme_constant_override("margin_bottom", 20)
	modal.add_child(margin)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	margin.add_child(box)
	box.add_child(_label("夢市冒險完成！", 24, INK, true))
	box.add_child(_label("第一關　%d / 100　　 第二關　%d / 100" % [scores[0], scores[1]], 19, Color("a76448"), true))
	box.add_child(_label("總分　%d / 200" % (scores[0] + scores[1]), 20, TEAL, true))
	var gain := posttest_score - pretest_score
	var direction := "進步 %d 題" % gain if gain > 0 else ("維持相同答對數" if gain == 0 else "再練習 %d 個概念" % abs(gain))
	box.add_child(_label("相同題目：開始前 %d / 2 → 遊戲後 %d / 2（%s）" % [pretest_score, posttest_score, direction], 17, Color("a76448"), true))
	box.add_child(_label("你練習了先安排需要與未來目標，也學會用備用和分散來思考風險。", 15, INK))
	var again := Button.new()
	again.text = "再玩一次"
	again.pressed.connect(_restart)
	_style_button(again, CORAL, Color("8a593e"), PAPER)
	box.add_child(again)
	modal.visible = true

func _restart() -> void:
	level = 0
	scores = [0, 0]
	attempts = [0, 0]
	coins = [4, 4, 2]
	seeds = [6, 0, 0]
	selected_reason = -1
	modal.visible = false
	action_button.text = "檢查分配"
	if action_button.pressed.is_connected(_advance_level):
		action_button.pressed.disconnect(_advance_level)
	if action_button.pressed.is_connected(_submit_answer):
		action_button.pressed.disconnect(_submit_answer)
	action_button.pressed.connect(_submit_answer)
	_show_level()
	_start_assessment(true)

func _process(delta: float) -> void:
	if not is_instance_valid(player): return
	var direction := Input.get_axis("ui_left", "ui_right")
	if Input.is_key_pressed(KEY_A): direction -= 1.0
	if Input.is_key_pressed(KEY_D): direction += 1.0
	player.position.x = clampf(player.position.x + direction * delta * 3.1, -7.2, 7.2)
	player.position.y = 0.025 * sin(Time.get_ticks_msec() * 0.006) if absf(direction) > 0.1 else 0.0

func _keys() -> int:
	return int(scores[0] > 0) + int(scores[1] > 0)

func _sum(values: Array) -> int:
	var total := 0
	for v in values: total += int(v)
	return total

func _label(text: String, size: int, color: Color, bold := false) -> Label:
	var result := Label.new()
	result.text = text
	result.add_theme_font_size_override("font_size", size)
	result.add_theme_color_override("font_color", color)
	if bold: result.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0))
	result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return result

func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.92
	return m

func _make_fallback_player() -> Node3D:
	var root := Node3D.new()
	var body := MeshInstance3D.new()
	var mesh := CapsuleMesh.new()
	mesh.radius = 0.42
	mesh.height = 1.4
	body.mesh = mesh
	body.material_override = _mat(Color("526b72"))
	body.position.y = 0.65
	root.add_child(body)
	return root

func _panel_style(fill: Color, border: Color, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(2)
	style.set_corner_radius_all(radius)
	style.shadow_color = Color(0.16, 0.19, 0.2, 0.16)
	style.shadow_size = 8
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	return style

func _style_button(button: Button, fill: Color, border: Color, text_color: Color) -> void:
	for state in ["normal", "hover", "pressed", "focus", "disabled"]:
		var c := fill
		if state == "hover": c = fill.lightened(0.08)
		if state == "pressed": c = fill.darkened(0.06)
		if state == "disabled": c = fill.darkened(0.15)
		button.add_theme_stylebox_override(state, _panel_style(c, border, 12))
	button.add_theme_color_override("font_color", text_color)
	button.add_theme_color_override("font_hover_color", text_color)
	button.add_theme_color_override("font_pressed_color", text_color)
	button.add_theme_font_size_override("font_size", 16)
	button.focus_mode = Control.FOCUS_ALL

func _unhandled_key_input(event: InputEvent) -> void:
	if modal.visible: return
	if event.is_action_pressed("ui_accept") and is_instance_valid(action_button):
		_submit_answer()
