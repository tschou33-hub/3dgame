# 夢市預算站

Godot 4 教育遊戲原型：小學生生活理財與投資風險入門。場景採紙雕童話方向，原創模型由 Blender 製作。

## 開啟方式

以 Godot 4.3 或更新版本匯入本資料夾的 `project.godot`，按 F6/F5 執行 `scenes/main.tscn`。

## 遊戲操作

- 以 A/D 或方向鍵移動小小夢行者。
- 第一關調整 10 枚夢幣，安排需要、想要與未來目標，選擇理由後檢查。
- 第二關把 6 顆星種分配到三種花盆，保留備用並分散選擇。
- 每關答對可取得鑰匙；每關顯示分數，結尾顯示兩關得分與學習成果。

每次首次通過得 100 分；每次重試扣 10 分，最低 60 分。遊戲使用虛構夢幣和星種，不提供投資建議或真實金融報酬模擬。

## Blender 資產

- `assets/dream_market_set.blend`：可編輯場景模型。
- `assets/dream_market_set.glb`：Godot 可匯入的 glTF 二進位場景。
- `tools/build_assets.py`：從頭生成原創紙雕風場景與角色的 Blender 腳本。

## 內容

- `visuals/`：三款同一狀態的視覺方向稿與比較頁。
- `scripts/main.gd`：關卡、互動、得分、鑰匙與結果畫面。
- `scenes/main.tscn`：Godot 主場景。
