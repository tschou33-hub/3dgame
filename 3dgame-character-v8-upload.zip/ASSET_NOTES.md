# Asset notes

| Asset ID | Purpose | Creator/tool | Source and license | Language dependency | Version/status |
|---|---|---|---|---|---|
| `dream_market_set.blend` | Editable 3D set and original paper-cut traveler | Generated locally with Blender 5.3.0 from `tools/build_assets.py` | Original geometry/materials; no third-party meshes or textures | None | v1; editable source |
| `dream_market_set.glb` | Godot import of the market, garden and traveler | Blender glTF 2.0 exporter | Export of the original Blender scene | None | v1; Godot scene asset |
| `dream-market-style-a.svg` | Rejected visual direction preview | Hand-authored SVG | Original vector mockup | Traditional Chinese UI text | v1; concept only |
| `dream-market-style-b.svg` | Approved visual direction preview | Hand-authored SVG | Original vector mockup | Traditional Chinese UI text | v1; reference for in-game paper-cut styling |
| `dream-market-style-c.svg` | Rejected visual direction preview | Hand-authored SVG | Original vector mockup | Traditional Chinese UI text | v1; concept only |

The project is inspired by broad side-view adventure and oversized-environment patterns. It does not reuse *Little Nightmares* characters, settings, models, textures, music, or other protected assets.
